namespace Manage_Store.Entity;

public class LabelItem
{
    
}