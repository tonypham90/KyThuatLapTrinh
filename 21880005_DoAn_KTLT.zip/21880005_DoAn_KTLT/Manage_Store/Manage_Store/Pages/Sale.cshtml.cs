using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Manage_Store.Pages;

public class Sale : PageModel
{
    public void OnGet()
    {
        
    }
}