using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Manage_Store.Pages;

public class Store : PageModel
{
    public void OnGet()
    {
        
    }
}